echo "sprefql"
#:sh runi.sh 10k
sh runi.sh 10k
sh runc.sh 10k
sh runa.sh 10k

