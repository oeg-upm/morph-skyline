curl -H "Accept: text/csv" --data-urlencode "query= PREFIX ex: <http://example.com/>

SELECT ?s ?d1s ?d2s ?d3s
WHERE { 
?s ex:d1 ?d1s .
?s ex:d2 ?d2s .
?s ex:d3 ?d3s .
}
PREFER (?s1 ?d1s1 ?d2s1 ?d3s1)
TO     (?s2 ?d1s2 ?d2s2 ?d3s2)
IF ( ?d1s2 <= ?d1s1 && ?d2s2 <= ?d2s1 && ?d3s2 <= ?d3s1 && (?d1s2 < ?d1s1 || ?d2s2 < ?d2s1 || ?d3s2 < ?d3s1))" http://localhost:8888/prefers-1.1/repositories/sparql
