curl -H "Accept: text/csv" --data-urlencode "query= PREFIX ex: <http://example.com/>

SELECT ?s ?d1s ?d2s
WHERE { 
?s ex:d1 ?d1s .
?s ex:d2 ?d2s .
}
PREFER (?s1 ?x1 ?y1)
TO     (?s2 ?x2 ?y2)
IF (?x1 <= ?x2 && ?y1 <= ?y2 
     && (?x1 < ?x2 || ?y1 < ?y2 ))" http://localhost:8888/prefers-1.1/repositories/sparql
