#!/bin/bash

#Parameter 1 refers to db size
for i in "i" "c" "a" 
do
	echo "Loading database "$i
	for q in 1 2 3 4 5 6 7 8 9
	do
		for t in 1 #2 3 4 5 
		do		

			echo "Loading database "$i
			rm -f data/virtuoso/virtuoso*
			sh loadDB.sh $i$1
			sleep 2m

			echo "size $1 db $i query $q run $t"
			# Run engine 
			start=$(date +%s.%N)
			res=$(timeout -s SIGKILL 60m sh dataset1-query$q.sh | wc -l)
			echo "$1, $i, $q, NL, $t, $res">> skyline${1}_${i}.csv
			#finish time
			finish=$(date +%s.%N)
			#duration
			dur=$(echo "$finish - $start" | bc)
			echo "$1, $i, $q, NL, $t, $dur">>results-times$i$1.csv
		done
	done
	echo "Claering database "$i
	rm -f data/virtuoso/virtuoso*
	docker-compose down --rmi all -v --remove-orphans
	docker-compose up -d
done
