docker exec virtuoso isql-v -U dba -P dba exec="ld_dir('./toLoad/','$1.nt', 'http://www.example.com/my-graph');rdf_loader_run();"

