curl -H "Accept: text/csv" --data-urlencode "query= PREFIX ex: <http://example.com/>

SELECT ?s ?d10s ?d2s ?d9s ?d6s ?d4s
WHERE { 
?s ex:d10 ?d10s .
?s ex:d2 ?d2s .
?s ex:d9 ?d9s .
?s ex:d6 ?d6s .
?s ex:d4 ?d4s .
}
PREFER (?s1 ?d10s1 ?d2s1 ?d9s1 ?d6s1 ?d4s1)
TO     (?s2 ?d10s2 ?d2s2 ?d9s2 ?d6s2 ?d4s2)
IF ( ?d10s2 <= ?d10s1 && ?d2s2 >= ?d2s1 && ?d9s2 <= ?d9s1 && ?d6s2 <= ?d6s1 && ?d4s2 >= ?d4s1 )" http://localhost:8888/prefers-1.1/repositories/sparql
