curl -H "Accept: text/csv" --data-urlencode "query= PREFIX ex: <http://example.com/>

SELECT ?s ?d8s ?d5s ?d7s ?d2s ?d9s
WHERE { 
?s ex:d8 ?d8s .
?s ex:d5 ?d5s .
?s ex:d7 ?d7s .
?s ex:d2 ?d2s .
?s ex:d9 ?d9s .
}
PREFER (?s1 ?d8s1 ?d5s1 ?d7s1 ?d2s1 ?d9s1)
TO     (?s2 ?d8s2 ?d5s2 ?d7s2 ?d2s2 ?d9s2)
IF ( ?d8s2 >= ?d8s1 && ?d5s2 <= ?d5s1 && ?d7s2 >= ?d7s1 && ?d2s2 >= ?d2s1 && ?d9s2 <= ?d9s1 )" http://localhost:8888/prefers-1.1/repositories/sparql
