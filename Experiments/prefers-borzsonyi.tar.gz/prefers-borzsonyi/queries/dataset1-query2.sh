curl -H "Accept: text/csv" --data-urlencode "query= PREFIX ex: <http://example.com/>

SELECT ?s ?d3s ?d4s
WHERE { 
?s ex:d3 ?d3s .
?s ex:d4 ?d4s .
}
PREFER (?s1 ?d3s1 ?d4s1)
TO     (?s2 ?d3s2 ?d4s2)
IF ( ?d3s2 >= ?d3s1 && ?d4s2 <= ?d4s1 )
" http://localhost:8888/prefers-1.1/repositories/sparql
