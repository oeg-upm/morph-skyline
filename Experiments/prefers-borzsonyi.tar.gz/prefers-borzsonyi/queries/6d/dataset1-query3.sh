curl -H "Accept: text/csv" --data-urlencode "query= PREFIX ex: <http://example.com/>

SELECT ?s ?d3s ?d10s ?d6s ?d7s ?d8s ?d9s
WHERE { 
?s ex:d3 ?d3s .
?s ex:d10 ?d10s .
?s ex:d6 ?d6s .
?s ex:d7 ?d7s .
?s ex:d8 ?d8s .
?s ex:d9 ?d9s .
}
PREFER (?s1 ?d3s1 ?d10s1 ?d6s1 ?d7s1 ?d8s1 ?d9s1)
TO     (?s2 ?d3s2 ?d10s2 ?d6s2 ?d7s2 ?d8s2 ?d9s2)
IF ( ?d3s2 <= ?d3s1 && ?d10s2 <= ?d10s1 && ?d6s2 <= ?d6s1 && ?d7s2 >= ?d7s1 && ?d8s2 >= ?d8s1 && ?d9s2 >= ?d9s1 )" http://localhost:8888/prefers-1.1/repositories/sparql
