curl -H "Accept: text/csv" --data-urlencode "query= PREFIX ex: <http://example.com/>

SELECT ?s ?d1s ?d4s ?d2s ?d3s ?d8s ?d7s
WHERE { 
?s ex:d1 ?d1s .
?s ex:d4 ?d4s .
?s ex:d2 ?d2s .
?s ex:d3 ?d3s .
?s ex:d8 ?d8s .
?s ex:d7 ?d7s .
}
PREFER (?s1 ?d1s1 ?d4s1 ?d2s1 ?d3s1 ?d8s1 ?d7s1)
TO     (?s2 ?d1s2 ?d4s2 ?d2s2 ?d3s2 ?d8s2 ?d7s2)
IF ( ?d1s2 <= ?d1s1 && ?d4s2 <= ?d4s1 && ?d2s2 <= ?d2s1 && ?d3s2 <= ?d3s1 && ?d8s2 >= ?d8s1 && ?d7s2 >= ?d7s1 )" http://localhost:8888/prefers-1.1/repositories/sparql
