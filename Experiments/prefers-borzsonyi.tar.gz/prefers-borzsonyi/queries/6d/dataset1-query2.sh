curl -H "Accept: text/csv" --data-urlencode "query= PREFIX ex: <http://example.com/>

SELECT ?s ?d9s ?d1s ?d6s ?d8s ?d4s ?d10s
WHERE { 
?s ex:d9 ?d9s .
?s ex:d1 ?d1s .
?s ex:d6 ?d6s .
?s ex:d8 ?d8s .
?s ex:d4 ?d4s .
?s ex:d10 ?d10s .
}
PREFER (?s1 ?d9s1 ?d1s1 ?d6s1 ?d8s1 ?d4s1 ?d10s1)
TO     (?s2 ?d9s2 ?d1s2 ?d6s2 ?d8s2 ?d4s2 ?d10s2)
IF ( ?d9s2 <= ?d9s1 && ?d1s2 <= ?d1s1 && ?d6s2 <= ?d6s1 && ?d8s2 <= ?d8s1 && ?d4s2 <= ?d4s1 && ?d10s2 <= ?d10s1 )" http://localhost:8888/prefers-1.1/repositories/sparql
