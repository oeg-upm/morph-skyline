curl -H "Accept: text/csv" --data-urlencode "query= PREFIX ex: <http://example.com/>

SELECT ?s ?d9s ?d6s
WHERE { 
?s ex:d9 ?d9s .
?s ex:d6 ?d6s .
}
PREFER (?s1 ?d9s1 ?d6s1)
TO     (?s2 ?d9s2 ?d6s2)
IF ( ?d9s2 >= ?d9s1 && ?d6s2 >= ?d6s1 )" http://localhost:8888/prefers-1.1/repositories/sparql
