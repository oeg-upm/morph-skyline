curl -H "Accept: text/csv" --data-urlencode "query= PREFIX ex: <http://example.com/>

SELECT ?s ?d5s ?d7s
WHERE { 
?s ex:d5 ?d5s .
?s ex:d7 ?d7s .
}
PREFER (?s1 ?d5s1 ?d7s1)
TO     (?s2 ?d5s2 ?d7s2)
IF ( ?d5s2 <= ?d5s1 && ?d7s2 >= ?d7s1 )" http://localhost:8888/prefers-1.1/repositories/sparql
