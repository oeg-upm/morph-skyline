curl -H "Accept: text/csv" --data-urlencode "query= PREFIX ex: <http://example.com/>

SELECT ?s ?d4s ?d2s ?d5s ?d6s
WHERE { 
?s ex:d4 ?d4s .
?s ex:d2 ?d2s .
?s ex:d5 ?d5s .
?s ex:d6 ?d6s .
}
PREFER (?s1 ?d4s1 ?d2s1 ?d5s1 ?d6s1)
TO     (?s2 ?d4s2 ?d2s2 ?d5s2 ?d6s2)
IF ( ?d4s2 <= ?d4s1 && ?d2s2 >= ?d2s1 && ?d5s2 <= ?d5s1 && ?d6s2 <= ?d6s1 )" http://localhost:8888/prefers-1.1/repositories/sparql
