curl -H "Accept: text/csv" --data-urlencode "query= PREFIX ex: <http://example.com/>

SELECT ?s ?d8s ?d6s ?d7s
WHERE { 
?s ex:d8 ?d8s .
?s ex:d6 ?d6s .
?s ex:d7 ?d7s .
}
PREFER (?s1 ?d8s1 ?d6s1 ?d7s1)
TO     (?s2 ?d8s2 ?d6s2 ?d7s2)
IF ( ?d8s2 <= ?d8s1 && ?d6s2 >= ?d6s1 && ?d7s2 >= ?d7s1 )" http://localhost:8888/prefers-1.1/repositories/sparql
