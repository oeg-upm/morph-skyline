curl -H "Accept: text/csv" --data-urlencode "query= PREFIX ex: <http://example.com/>

SELECT ?s ?d9s ?d8s ?d4s
WHERE { 
?s ex:d9 ?d9s .
?s ex:d8 ?d8s .
?s ex:d4 ?d4s .
}
PREFER (?s1 ?d9s1 ?d8s1 ?d4s1)
TO     (?s2 ?d9s2 ?d8s2 ?d4s2)
IF ( ?d9s2 >= ?d9s1 && ?d8s2 >= ?d8s1 && ?d4s2 <= ?d4s1 )" http://localhost:8888/prefers-1.1/repositories/sparql
