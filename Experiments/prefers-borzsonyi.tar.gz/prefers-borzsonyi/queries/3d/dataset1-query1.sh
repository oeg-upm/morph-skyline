curl -H "Accept: text/csv" --data-urlencode "query= PREFIX ex: <http://example.com/>

SELECT ?s ?d3s ?d8s ?d2s
WHERE { 
?s ex:d3 ?d3s .
?s ex:d8 ?d8s .
?s ex:d2 ?d2s .
}
PREFER (?s1 ?d3s1 ?d8s1 ?d2s1)
TO     (?s2 ?d3s2 ?d8s2 ?d2s2)
IF ( ?d3s2 <= ?d3s1 && ?d8s2 >= ?d8s1 && ?d2s2 <= ?d2s1 )" http://localhost:8888/prefers-1.1/repositories/sparql
