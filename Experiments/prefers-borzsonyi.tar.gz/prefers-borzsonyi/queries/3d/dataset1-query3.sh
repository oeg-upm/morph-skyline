curl -H "Accept: text/csv" --data-urlencode "query= PREFIX ex: <http://example.com/>

SELECT ?s ?d4s ?d9s ?d3s
WHERE { 
?s ex:d4 ?d4s .
?s ex:d9 ?d9s .
?s ex:d3 ?d3s .
}
PREFER (?s1 ?d4s1 ?d9s1 ?d3s1)
TO     (?s2 ?d4s2 ?d9s2 ?d3s2)
IF ( ?d4s2 >= ?d4s1 && ?d9s2 >= ?d9s1 && ?d3s2 <= ?d3s1 )" http://localhost:8888/prefers-1.1/repositories/sparql
